
#if !defined(_main_h)
#define _main_h

#include "usloss.h"

dynamic_dcl USLOSS_Context finish_context;
dynamic_dcl int finish_status;

#endif	/*  _main_h */

